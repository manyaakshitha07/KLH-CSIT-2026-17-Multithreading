# System Architecture

## Components

1. **Input handler (main thread):** validates arguments and reads the log file.
2. **Work distributor:** divides the line array into approximately equal chunks.
3. **Worker threads:** each worker classifies its assigned lines and updates only its own counters.
4. **Aggregator:** the main thread waits for workers and sums their counters.
5. **Output/timing:** prints totals and elapsed analysis time.

## Processing flow

```text
Start
  |
Validate arguments
  |
Open and read log file
  |
Divide lines among worker threads
  |
Create worker threads
  |
Each thread classifies its assigned lines
  |
Join all worker threads
  |
Combine per-thread statistics
  |
Print totals and elapsed time
  |
Free memory and exit
```

## Concurrency design

Workers do not share writable counters. Each thread writes to its own `ThreadData.stats`; the main thread combines the counters after `pthread_join`. This avoids a mutex for the statistics in this design.

## Complexity

Let N be the number of log lines and L be the total number of characters examined. Classification takes O(L) total work. The file and its line pointers are stored in memory, requiring memory proportional to the file size. Parallel speedup depends on file size, CPU cores, and thread overhead.

# Test Report

Project: Multithreaded Log Analysis System  
Environment: Ubuntu / WSL with GCC  
Date: __________________  
Tester(s): __________________

## Test cases

| ID | Command / scenario | Expected result | Actual result | Status |
|---|---|---|---|---|
| T1 | `./log_analyzer sample.log 1` | Counts: INFO 3, WARNING 2, ERROR 3, Other 1 | Fill after running | Pending |
| T2 | `./log_analyzer sample.log 2` | Same category counts as T1 | Fill after running | Pending |
| T3 | `./log_analyzer sample.log 4` | Same category counts as T1 | Fill after running | Pending |
| T4 | `./log_analyzer missing.log 4` | File-open error; nonzero exit | Fill after running | Pending |
| T5 | `./log_analyzer sample.log 0` | Invalid thread count error; nonzero exit | Fill after running | Pending |
| T6 | `./log_analyzer sample.log abc` | Invalid thread count error; nonzero exit | Fill after running | Pending |

## Performance experiment

Use a sufficiently large log file and repeat each configuration several times. Record results honestly; do not infer a speedup from the 9-line sample.

| Threads | Run 1 (seconds) | Run 2 (seconds) | Run 3 (seconds) | Average |
|---:|---:|---:|---:|---:|
| 1 | | | | |
| 2 | | | | |
| 4 | | | | |

## Notes

- Record actual results, system details, and any deviations.
- Execution times will vary between machines and runs.

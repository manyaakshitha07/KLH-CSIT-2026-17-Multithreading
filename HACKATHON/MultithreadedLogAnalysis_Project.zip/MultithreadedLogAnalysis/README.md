# Multithreaded Log Analysis System

A C-based command-line prototype that analyzes a text log file using POSIX threads. It counts lines containing `ERROR`, `WARNING`, `INFO`, and other messages, and reports the analysis time.

## Features

- Parallel log-line classification with POSIX threads (`pthread_create` / `pthread_join`)
- Case-insensitive keyword matching
- Per-thread statistics, combined after workers finish
- Input validation and basic file/allocation error handling
- Elapsed-time measurement using `clock_gettime(CLOCK_MONOTONIC)`

## Requirements

- Linux or Ubuntu/WSL
- GCC
- POSIX threads (provided by the standard Linux build environment)

Install build tools on Ubuntu:

```bash
sudo apt update
sudo apt install build-essential
```

## Build

From this directory:

```bash
gcc -Wall -Wextra -std=c11 -pthread log_analyzer.c -o log_analyzer
```

Or use the Makefile:

```bash
make
```

## Run

```bash
./log_analyzer sample.log 4
```

The second argument is the number of worker threads (1–256).

## Expected sample counts

For the included `sample.log` (9 lines):

- INFO: 3
- WARNING: 2
- ERROR: 3
- Other: 1
- Total: 9

Execution time varies by machine and load. The sample is too small to demonstrate a meaningful speedup. For performance experiments, generate a larger log file and compare repeated runs using 1, 2, and 4 threads.

## Tests

```bash
./log_analyzer sample.log 1
./log_analyzer sample.log 2
./log_analyzer sample.log 4
./log_analyzer missing.log 4
./log_analyzer sample.log 0
```

The valid runs should produce the same category counts. The invalid thread count and missing file should produce an error.

## Design

1. The main thread reads the file and stores its lines.
2. The program divides the line range among worker threads.
3. Each worker counts categories in its own `LogStats` structure.
4. The main thread joins workers and combines their statistics.
5. The program prints counts and elapsed analysis time.

## Limitations

- The entire file is loaded into memory before analysis.
- Classification is based on keywords, not a strict log-format parser.
- If a line contains more than one keyword, priority is `ERROR`, then `WARNING`, then `INFO`.
- Small files may not benefit from multiple threads because thread-management overhead can outweigh parallel work.

## Suggested future work

- Write results to a CSV or text report
- Show individual error lines
- Add date/time filtering and severity filters
- Stream very large files without loading all lines into memory
- Add automated tests and benchmark graphs

## Repository contents

- `log_analyzer.c` — application source
- `sample.log` — sample input
- `docs/architecture.md` — design notes
- `docs/test-report.md` — test plan and result template
- `tests/` — place additional test data or scripts here

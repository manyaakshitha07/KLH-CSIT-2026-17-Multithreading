#define _GNU_SOURCE
#define _POSIX_C_SOURCE 200809L

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/types.h>
#include <pthread.h>
#include <time.h>

typedef struct {
    size_t info;
    size_t warning;
    size_t error;
    size_t other;
} LogStats;

typedef struct {
    char **lines;
    size_t start;
    size_t end;
    LogStats stats;
} ThreadData;

static void *analyze_logs(void *arg) {
    ThreadData *data = (ThreadData *)arg;

    for (size_t i = data->start; i < data->end; i++) {
        if (strcasestr(data->lines[i], "ERROR")) {
            data->stats.error++;
        } else if (strcasestr(data->lines[i], "WARNING")) {
            data->stats.warning++;
        } else if (strcasestr(data->lines[i], "INFO")) {
            data->stats.info++;
        } else {
            data->stats.other++;
        }
    }

    return NULL;
}

static void free_lines(char **lines, size_t count) {
    if (lines == NULL) return;
    for (size_t i = 0; i < count; i++) {
        free(lines[i]);
    }
    free(lines);
}

int main(int argc, char *argv[]) {
    if (argc != 3) {
        fprintf(stderr, "Usage: %s <log_file> <number_of_threads>\n", argv[0]);
        return EXIT_FAILURE;
    }

    char *endptr = NULL;
    long thread_count = strtol(argv[2], &endptr, 10);
    if (argv[2][0] == '\0' || endptr == argv[2] || *endptr != '\0' ||
        thread_count < 1 || thread_count > 256) {
        fprintf(stderr, "Error: thread count must be an integer from 1 to 256.\n");
        return EXIT_FAILURE;
    }

    FILE *file = fopen(argv[1], "r");
    if (file == NULL) {
        perror("Error opening log file");
        return EXIT_FAILURE;
    }

    char **lines = NULL;
    size_t count = 0;
    size_t capacity = 0;
    char *line = NULL;
    size_t line_capacity = 0;
    ssize_t length;

    while ((length = getline(&line, &line_capacity, file)) != -1) {
        if (count == capacity) {
            size_t new_capacity = (capacity == 0) ? 128 : capacity * 2;
            char **new_lines = realloc(lines, new_capacity * sizeof(*lines));
            if (new_lines == NULL) {
                perror("Memory allocation failed");
                free(line);
                fclose(file);
                free_lines(lines, count);
                return EXIT_FAILURE;
            }
            lines = new_lines;
            capacity = new_capacity;
        }

        lines[count] = malloc((size_t)length + 1);
        if (lines[count] == NULL) {
            perror("Memory allocation failed");
            free(line);
            fclose(file);
            free_lines(lines, count);
            return EXIT_FAILURE;
        }
        memcpy(lines[count], line, (size_t)length + 1);
        count++;
    }

    if (ferror(file)) {
        perror("Error reading log file");
        free(line);
        fclose(file);
        free_lines(lines, count);
        return EXIT_FAILURE;
    }
    free(line);
    fclose(file);

    pthread_t *threads = calloc((size_t)thread_count, sizeof(*threads));
    ThreadData *thread_data = calloc((size_t)thread_count, sizeof(*thread_data));
    if (threads == NULL || thread_data == NULL) {
        perror("Memory allocation failed");
        free(threads);
        free(thread_data);
        free_lines(lines, count);
        return EXIT_FAILURE;
    }

    struct timespec start_time, end_time;
    if (clock_gettime(CLOCK_MONOTONIC, &start_time) != 0) {
        perror("clock_gettime");
        free(threads);
        free(thread_data);
        free_lines(lines, count);
        return EXIT_FAILURE;
    }

    size_t base_chunk = count / (size_t)thread_count;
    size_t remainder = count % (size_t)thread_count;
    size_t start = 0;
    long created = 0;

    for (long i = 0; i < thread_count; i++) {
        size_t chunk = base_chunk + ((size_t)i < remainder ? 1 : 0);
        thread_data[i].lines = lines;
        thread_data[i].start = start;
        thread_data[i].end = start + chunk;
        start += chunk;

        int rc = pthread_create(&threads[i], NULL, analyze_logs, &thread_data[i]);
        if (rc != 0) {
            fprintf(stderr, "Error: could not create thread %ld (code %d).\n", i, rc);
            for (long j = 0; j < created; j++) {
                pthread_join(threads[j], NULL);
            }
            free(threads);
            free(thread_data);
            free_lines(lines, count);
            return EXIT_FAILURE;
        }
        created++;
    }

    LogStats total = {0, 0, 0, 0};
    for (long i = 0; i < created; i++) {
        int rc = pthread_join(threads[i], NULL);
        if (rc != 0) {
            fprintf(stderr, "Warning: could not join thread %ld (code %d).\n", i, rc);
        }
        total.info += thread_data[i].stats.info;
        total.warning += thread_data[i].stats.warning;
        total.error += thread_data[i].stats.error;
        total.other += thread_data[i].stats.other;
    }

    if (clock_gettime(CLOCK_MONOTONIC, &end_time) != 0) {
        perror("clock_gettime");
        free(threads);
        free(thread_data);
        free_lines(lines, count);
        return EXIT_FAILURE;
    }

    double elapsed = (double)(end_time.tv_sec - start_time.tv_sec) +
                     (double)(end_time.tv_nsec - start_time.tv_nsec) / 1e9;

    printf("\n===== MULTITHREADED LOG ANALYSIS =====\n");
    printf("File: %s\n", argv[1]);
    printf("Threads: %ld\n", thread_count);
    printf("Total lines: %zu\n", count);
    printf("INFO: %zu\n", total.info);
    printf("WARNING: %zu\n", total.warning);
    printf("ERROR: %zu\n", total.error);
    printf("Other: %zu\n", total.other);
    printf("Analysis time: %.6f seconds\n\n", elapsed);

    free(threads);
    free(thread_data);
    free_lines(lines, count);
    return EXIT_SUCCESS;
}
